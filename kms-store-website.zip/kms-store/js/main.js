// KMS Departmental Store - Main JavaScript
// Product Database
const products = [
    // Groceries
    { id: 1, name: "Basmati Rice", category: "groceries", price: 280, unit: "5kg", image: "🍚", badge: "Popular" },
    { id: 2, name: "Toor Dal", category: "groceries", price: 120, unit: "1kg", image: "🫘", badge: "" },
    { id: 3, name: "Sunflower Oil", category: "groceries", price: 180, unit: "1L", image: "🛢️", badge: "" },
    { id: 4, name: "Turmeric Powder", category: "groceries", price: 45, unit: "100g", image: "🟡", badge: "" },
    { id: 5, name: "Red Chili Powder", category: "groceries", price: 55, unit: "100g", image: "🌶️", badge: "" },
    { id: 6, name: "Garam Masala", category: "groceries", price: 65, unit: "50g", image: "🧂", badge: "" },
    { id: 7, name: "Wheat Flour", category: "groceries", price: 45, unit: "1kg", image: "🌾", badge: "" },
    { id: 8, name: "Sugar", category: "groceries", price: 42, unit: "1kg", image: "🍬", badge: "" },

    // Snacks
    { id: 9, name: "Lays Chips", category: "snacks", price: 20, unit: "pack", image: "🥔", badge: "Best Seller" },
    { id: 10, name: "Kurkure", category: "snacks", price: 15, unit: "pack", image: "🌽", badge: "" },
    { id: 11, name: "Biscuits (Parle-G)", category: "snacks", price: 10, unit: "pack", image: "🍪", badge: "" },
    { id: 12, name: "Namkeen Mixture", category: "snacks", price: 80, unit: "250g", image: "🥨", badge: "" },
    { id: 13, name: "Chocolate Bar", category: "snacks", price: 40, unit: "piece", image: "🍫", badge: "" },
    { id: 14, name: "Popcorn", category: "snacks", price: 25, unit: "pack", image: "🍿", badge: "" },

    // Juices & Beverages
    { id: 15, name: "Real Mixed Fruit Juice", category: "juices", price: 99, unit: "1L", image: "🧃", badge: "Offer" },
    { id: 16, name: "Maaza Mango Drink", category: "juices", price: 45, unit: "600ml", image: "🥭", badge: "" },
    { id: 17, name: "Coca Cola", category: "juices", price: 40, unit: "750ml", image: "🥤", badge: "" },
    { id: 18, name: "Mineral Water", category: "juices", price: 20, unit: "1L", image: "💧", badge: "" },
    { id: 19, name: "Sprite", category: "juices", price: 40, unit: "750ml", image: "🍋", badge: "" },
    { id: 20, name: "Fanta Orange", category: "juices", price: 40, unit: "750ml", image: "🍊", badge: "" },

    // Toys
    { id: 21, name: "Toy Car", category: "toys", price: 150, unit: "piece", image: "🚗", badge: "New" },
    { id: 22, name: "Teddy Bear", category: "toys", price: 250, unit: "piece", image: "🧸", badge: "" },
    { id: 23, name: "Building Blocks", category: "toys", price: 199, unit: "set", image: "🧱", badge: "" },
    { id: 24, name: "Ball (Cricket)", category: "toys", price: 80, unit: "piece", image: "🏏", badge: "" },
    { id: 25, name: "Doll Set", category: "toys", price: 299, unit: "set", image: "🎎", badge: "" },

    // Other Essentials
    { id: 26, name: "Bathing Soap (Lifebuoy)", category: "essentials", price: 35, unit: "piece", image: "🧼", badge: "" },
    { id: 27, name: "Toothpaste (Colgate)", category: "essentials", price: 55, unit: "100g", image: "🦷", badge: "" },
    { id: 28, name: "Tissue Paper", category: "essentials", price: 40, unit: "pack", image: "🧻", badge: "" },
    { id: 29, name: "Shampoo", category: "essentials", price: 120, unit: "200ml", image: "🧴", badge: "" },
    { id: 30, name: "Detergent Powder", category: "essentials", price: 85, unit: "1kg", image: "🫧", badge: "" }
];

// Special Offers
const offers = [
    { id: 1, title: "Buy any juice + get 10% off", description: "Valid on all 1L juice packs", code: "JUICE10" },
    { id: 2, title: "Free delivery on orders above ₹500", description: "Use code: FREEDEL", code: "FREEDEL" },
    { id: 3, title: "Buy 2 Rice bags, get 1kg Dal free", description: "Limited time offer", code: "RICE2" }
];

// Store Configuration
const STORE = {
    name: "KMS Departmental Store",
    phone: "919876543210", // Replace with actual WhatsApp number
    email: "kmsstore@example.com", // Replace with actual email
    address: "Main Road, Near Bus Stand",
    hours: "8:00 AM – 10:00 PM (Mon–Sun)",
    mapLink: "https://maps.google.com"
};

// ===== CART FUNCTIONS =====
function getCart() {
    return JSON.parse(localStorage.getItem('kms_cart')) || [];
}

function saveCart(cart) {
    localStorage.setItem('kms_cart', JSON.stringify(cart));
    updateCartCount();
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    let cart = getCart();
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.qty += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            unit: product.unit,
            image: product.image,
            qty: 1
        });
    }

    saveCart(cart);
    showToast(`${product.name} added to cart!`, 'success');

    // Update button state
    const btn = document.querySelector(`[data-product-id="${productId}"]`);
    if (btn) {
        btn.innerHTML = '✓ Added';
        btn.classList.add('added');
        setTimeout(() => {
            btn.innerHTML = '🛒 Add to Cart';
            btn.classList.remove('added');
        }, 1500);
    }
}

function removeFromCart(productId) {
    let cart = getCart();
    cart = cart.filter(item => item.id !== productId);
    saveCart(cart);
    renderCart();
    showToast('Item removed from cart', 'success');
}

function updateQty(productId, change) {
    let cart = getCart();
    const item = cart.find(item => item.id === productId);

    if (item) {
        item.qty += change;
        if (item.qty <= 0) {
            removeFromCart(productId);
            return;
        }
        saveCart(cart);
        renderCart();
    }
}

function updateCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    const countElements = document.querySelectorAll('.cart-count');
    countElements.forEach(el => el.textContent = count);
}

function clearCart() {
    localStorage.removeItem('kms_cart');
    updateCartCount();
}

// ===== PRODUCT DISPLAY =====
function renderProducts(containerId, category = 'all', limit = null) {
    const container = document.getElementById(containerId);
    if (!container) return;

    let filtered = category === 'all' ? products : products.filter(p => p.category === category);
    if (limit) filtered = filtered.slice(0, limit);

    container.innerHTML = filtered.map(product => `
        <div class="product-card fade-in">
            <div class="product-image">
                ${product.badge ? `<span class="product-badge ${product.badge.toLowerCase().replace(' ', '-')}">${product.badge}</span>` : ''}
                <span style="font-size: 4rem;">${product.image}</span>
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-unit">${product.unit}</p>
                <p class="product-price">₹${product.price}</p>
                <button class="add-to-cart" data-product-id="${product.id}" onclick="addToCart(${product.id})">
                    🛒 Add to Cart
                </button>
            </div>
        </div>
    `).join('');
}

function renderFeaturedProducts() {
    const featured = products.filter(p => p.badge !== '');
    renderProducts('featured-products', 'all', 8);
}

// ===== CART PAGE =====
function renderCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartSummaryContainer = document.getElementById('cart-summary');

    if (!cartItemsContainer) return;

    const cart = getCart();

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h3>Your cart is empty</h3>
                <p>Add some items to get started!</p>
                <a href="products.html" class="continue-shopping">Continue Shopping</a>
            </div>
        `;
        if (cartSummaryContainer) cartSummaryContainer.style.display = 'none';
        return;
    }

    let subtotal = 0;

    cartItemsContainer.innerHTML = cart.map(item => {
        const itemTotal = item.price * item.qty;
        subtotal += itemTotal;
        return `
            <div class="cart-item">
                <div class="cart-item-image">${item.image}</div>
                <div class="cart-item-details">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">₹${item.price} / ${item.unit}</div>
                    <div class="quantity-control">
                        <button class="qty-btn" onclick="updateQty(${item.id}, -1)">−</button>
                        <span class="qty-value">${item.qty}</span>
                        <button class="qty-btn" onclick="updateQty(${item.id}, 1)">+</button>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="font-weight: 700; color: var(--primary);">₹${itemTotal}</div>
                    <button class="remove-btn" onclick="removeFromCart(${item.id})">🗑️</button>
                </div>
            </div>
        `;
    }).join('');

    // Update summary
    const gst = Math.round(subtotal * 0.05);
    const total = subtotal + gst;

    if (cartSummaryContainer) {
        cartSummaryContainer.style.display = 'block';
        document.getElementById('subtotal').textContent = `₹${subtotal}`;
        document.getElementById('gst').textContent = `₹${gst}`;
        document.getElementById('total').textContent = `₹${total}`;
    }
}

// ===== ORDER SUBMISSION =====
function submitOrder() {
    const name = document.getElementById('customer-name').value.trim();
    const phone = document.getElementById('customer-phone').value.trim();
    const address = document.getElementById('customer-address').value.trim();
    const orderType = document.getElementById('order-type').value;

    if (!name || !phone) {
        showToast('Please fill in your name and phone number', 'error');
        return;
    }

    const cart = getCart();
    if (cart.length === 0) {
        showToast('Your cart is empty', 'error');
        return;
    }

    let itemsText = '';
    let total = 0;
    cart.forEach(item => {
        const itemTotal = item.qty * item.price;
        itemsText += `${item.qty}x ${item.name} (₹${item.price} each) = ₹${itemTotal}\n`;
        total += itemTotal;
    });

    const gst = Math.round(total * 0.05);
    const grandTotal = total + gst;

    const orderText = `*NEW ORDER - ${STORE.name}*\n\n` +
        `*Customer:* ${name}\n` +
        `*Phone:* ${phone}\n` +
        `*Address:* ${address || 'N/A'}\n` +
        `*Order Type:* ${orderType}\n\n` +
        `*Items:*\n${itemsText}\n` +
        `Subtotal: ₹${total}\n` +
        `GST (5%): ₹${gst}\n` +
        `*Total: ₹${grandTotal}*\n\n` +
        `Thank you for shopping with us!`;

    // WhatsApp
    const waLink = `https://wa.me/${STORE.phone}?text=${encodeURIComponent(orderText)}`;
    window.open(waLink, '_blank');

    // Email (using mailto as fallback)
    const emailSubject = `New Order from ${name}`;
    const emailBody = orderText.replace(/\n/g, '%0D%0A').replace(/\*/g, '');
    const emailLink = `mailto:${STORE.email}?subject=${encodeURIComponent(emailSubject)}&body=${emailBody}`;

    // Try to open email in new tab after a short delay
    setTimeout(() => {
        window.open(emailLink, '_blank');
    }, 1000);

    // Clear cart and redirect
    clearCart();
    setTimeout(() => {
        window.location.href = 'thank-you.html';
    }, 2000);

    showToast('Order submitted! Redirecting...', 'success');
}

// ===== SEARCH =====
function searchProducts(query) {
    query = query.toLowerCase().trim();
    if (!query) return products;

    return products.filter(p => 
        p.name.toLowerCase().includes(query) || 
        p.category.toLowerCase().includes(query)
    );
}

function handleSearch() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    const query = searchInput.value;
    const results = searchProducts(query);

    const container = document.getElementById('products-grid');
    if (!container) return;

    if (results.length === 0) {
        container.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🔍</div>
                <h3>No products found</h3>
                <p>Try searching for something else</p>
            </div>
        `;
        return;
    }

    container.innerHTML = results.map(product => `
        <div class="product-card fade-in">
            <div class="product-image">
                ${product.badge ? `<span class="product-badge ${product.badge.toLowerCase().replace(' ', '-')}">${product.badge}</span>` : ''}
                <span style="font-size: 4rem;">${product.image}</span>
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-unit">${product.unit}</p>
                <p class="product-price">₹${product.price}</p>
                <button class="add-to-cart" data-product-id="${product.id}" onclick="addToCart(${product.id})">
                    🛒 Add to Cart
                </button>
            </div>
        </div>
    `).join('');
}

// ===== TOAST NOTIFICATION =====
function showToast(message, type = 'success') {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = type === 'success' ? `✅ ${message}` : `❌ ${message}`;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ===== MOBILE MENU =====
function toggleMenu() {
    const navLinks = document.getElementById('nav-links');
    navLinks.classList.toggle('active');
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();

    // Initialize page-specific functions
    const page = document.body.dataset.page;

    if (page === 'home') {
        renderFeaturedProducts();
        renderOffers();
    } else if (page === 'products') {
        const urlParams = new URLSearchParams(window.location.search);
        const category = urlParams.get('category') || 'all';
        renderProducts('products-grid', category);

        // Set category filter
        const categorySelect = document.getElementById('category-filter');
        if (categorySelect) categorySelect.value = category;
    } else if (page === 'cart') {
        renderCart();
    }

    // Search functionality
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleSearch();
            }
        });
    }

    // Category filter
    const categoryFilter = document.getElementById('category-filter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            const category = this.value;
            renderProducts('products-grid', category);
        });
    }

    // Sort functionality
    const sortSelect = document.getElementById('sort-select');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            const sortType = this.value;
            let sorted = [...products];

            if (sortType === 'price-low') {
                sorted.sort((a, b) => a.price - b.price);
            } else if (sortType === 'price-high') {
                sorted.sort((a, b) => b.price - a.price);
            } else if (sortType === 'name') {
                sorted.sort((a, b) => a.name.localeCompare(b.name));
            }

            const container = document.getElementById('products-grid');
            if (container) {
                container.innerHTML = sorted.map(product => `
                    <div class="product-card fade-in">
                        <div class="product-image">
                            ${product.badge ? `<span class="product-badge ${product.badge.toLowerCase().replace(' ', '-')}">${product.badge}</span>` : ''}
                            <span style="font-size: 4rem;">${product.image}</span>
                        </div>
                        <div class="product-info">
                            <h3 class="product-name">${product.name}</h3>
                            <p class="product-unit">${product.unit}</p>
                            <p class="product-price">₹${product.price}</p>
                            <button class="add-to-cart" data-product-id="${product.id}" onclick="addToCart(${product.id})">
                                🛒 Add to Cart
                            </button>
                        </div>
                    </div>
                `).join('');
            }
        });
    }
});

// ===== RENDER OFFERS =====
function renderOffers() {
    const container = document.getElementById('offers-container');
    if (!container) return;

    container.innerHTML = offers.map(offer => `
        <div class="offers-banner">
            <h3>${offer.title}</h3>
            <p>${offer.description}</p>
        </div>
    `).join('');
}
